const prompt = require('prompt-sync')();
let temperatura = []
let estacao = {
    id: "",
    local: '' ,
    temperaturas: temperatura
}
temperatura.push(Number(prompt("digite a primeira temperatura:  ")));
temperatura.push(Number(prompt("digite a segunda temperatura:   ")));
temperatura.push(Number(prompt("digite a terceira temperatura:  ")));


 function media(temperatura) {
     return (temperatura[0]+temperatura[1]+temperatura[2])/3;
 } 
 
if (media(temperatura) >= 35) {
        estacao.alerta===true
        console.log("perigo: media de temperatura extrema");
}else {
    estacao.alerta === false
    console.log("temperaturas dentro da normalidade");
}
console.log(estacao);